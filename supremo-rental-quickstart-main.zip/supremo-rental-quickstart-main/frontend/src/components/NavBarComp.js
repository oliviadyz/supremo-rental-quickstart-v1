import React, { Component } from 'react'

export default class NavBarComp extends Component {
  render() {
    return (
      <div>
        <h2>Navbar</h2>
      </div>
    )
  }
}
