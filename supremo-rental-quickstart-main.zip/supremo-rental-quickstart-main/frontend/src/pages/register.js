import React from 'react'

function register() {
  return (
    <div>
      
    </div>
  )
}

export default register
