import React, { Component } from 'react'


export default class Home extends Component {
  render() {
    return (
      <div>
    <h2>this from component folder </h2>
      </div>
    )
  }
}
